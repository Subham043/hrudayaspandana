<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_services extends CI_Model {

    public function insertServices($data)
    {
        $this->db->insert('services',$data);
        $insertId = $this->db->insert_id();
        if ($insertId) {
            return $insertId;
        }else{
            return false;
        }
    }

    public function insertGallery($data)
    {
        $this->db->insert('gallery',$data);
        $insertId = $this->db->insert_id();
        if ($insertId) {
            return $insertId;
        }else{
            return false;
        }
    }


    public function getService($id){
        return  $this->db->where('id',$id)->get('services')->row();
    }

    public function deleteService($id){
        $this->db->where('id',$id);
		if($this->db->delete('services')){
            return true;
        }else{
            return false;
        }
		
    }

    public function updateService($data, $id){
        $this->db->where('id',$id);
		if($this->db->update('services', $data)){
            return true;
        }else{
            return false;
        }
		
    }

    public function updateServiceGallery($data, $id){
        $this->db->where('service_id',$id);
		if($this->db->update('gallery', $data)){
            return true;
        }else{
            return false;
        }
		
    }

    public function serviceGet($type){
        return  $this->db->where('type', $type)->order_by('id','desc')->get('services')->result();
    }

    public function serviceGetById($id){
        return  $this->db->where('service_id', $id)->order_by('id','desc')->get('gallery')->result();
    }

    public function deleteHomeGalleryImage($id){
        $this->db->where('service_id',$id);
		if($this->db->delete('gallery')){
            return true;
        }else{
            return false;
        }
		
    }

}

/* End of file M_adminuser.php */
/* Location: ./application/models/M_adminuser.php */